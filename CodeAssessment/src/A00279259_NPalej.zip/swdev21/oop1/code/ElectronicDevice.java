/** 
 * Natalia Palej A00279259 
 **/

package swdev21.oop1.code;

public interface ElectronicDevice {
	public void turnOn();
	public void turnOff();
	public String getTheMake();
	public String getTheModel();
}
