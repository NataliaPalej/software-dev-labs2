/** 
 * Natalia Palej A00279259 
 **/

package swdev21.oop1.code;

public interface HighlyDesirable {

}
